#include "Bibliotecas/SistemaDeGestion.h"

int main() {
    SistemaDeGestion sistema;

    sistema.cargarCategorias("ArchivosDeDatos/Categorias.csv");
    sistema.cargaComentarios("ArchivosDeDatos/Comentarios.csv");
    sistema.cargaEtiquetas("ArchivosDeDatos/Etiquetas.csv");
    sistema.cargaStreamers("ArchivosDeDatos/Streamers.csv");
    sistema.completarStreamers();
    sistema.reporteDeStreamers("ArchivosDeReporte/Reporte.txt");
    sistema.eliminaStreamers("Español");
    sistema.reporteDeStreamers("ArchivosDeReporte/ReporteDepurado.txt");

    return 0;
}
